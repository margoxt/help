import java.util.Scanner;
import java.text.DecimalFormat;
import java.util.InputMismatchException;

public class Menus {

    static Scanner rosh = new Scanner(System.in);
    static DecimalFormat df = new DecimalFormat("#,##0.00");
    public void seeMenu(String name){
        GetSet eto = new GetSet();

        while(true){
            System.out.println("\nWelcome " + name + "!\n");
            System.out.println("What would you like to do?");
            System.out.println("""
                    [1] Deposit
                    [2] Withdraw
                    [3] View User Details
                    [4] Exit
                    """);

                try{
                    System.out.print("Enter choice: "); int choice = rosh.nextInt();
                    switch(choice){
                        case 1 : deposit(eto.previousBalance, eto.currentBalance); break; 
                        case 2 : withdraw(eto.previousBalance, eto.currentBalance); break;
                        case 3 : userDetails(); break;
                        case 4 : check(); break;
                        default : System.out.println("Invalid Input. Try Again.");
                    }
                }
                catch(InputMismatchException lenon){
                    System.out.print("Invalid Input. Please enter a number.\n"); rosh.next();
                }
        }  
    }

    public double deposit(double currentBalance, double previousBalance){

            GetSet yo = new GetSet();
            while(true) {
                System.out.println("Balance: Php " + df.format(yo.computeCurrentBalance()));
                System.out.print("Input the amount of money to deposit: Php ");
              
                    yo.setDeposit(rosh.nextDouble());
                    if (yo.deposit <= 0) {
                        System.out.println("Invalid input. Input a positive number.");
                        continue;
                    } 
                    else{ 
                        break;
                    }
            }
                System.out.println("New balance: Php " + df.format(yo.computeCurrentBalance())); 
                yo.previousBalance = yo.computeCurrentBalance() ;
            while(true){
                System.out.println("[1] Return to Main Menu");
                System.out.println("[2] Exit");
                System.out.print("Enter your choice: ");
                int choice = rosh.nextInt();
                if(choice == 1){
                    return previousBalance; // + previousbal
                }
                else if(choice == 2){
                    System.out.println("Program ending...");
                    System.exit(0);
                }
                else{
                    System.out.println("Invalid choice.");
                }
            }

    }
    public double withdraw(double currentBalance, double previousBalance){
  
        GetSet go = new GetSet();
        while(true){
            try{
                System.out.println("Balance: "+ go.computeCurrentBalance()); 
                System.out.print("\nEnter amount to Withdraw: "); go.setWithdraw(rosh.nextDouble()); 
         
                    if(go.computeCurrentBalance() < 200){
                        System.out.println("Insufficient balance, you cannot withdraw.\nPlease re-enter an amount.\n"); continue;
                    }
                    else{
                    }
            
                check();
                System.out.println("\nCurrent Balance: "+ df.format(go.computeCurrentBalance()));
                System.out.println("Congratulations you have successfully withdrawn PHP "+ df.format(go.getWithdraw()));
                go.previousBalance = go.currentBalance;
                    
                        System.out.println("\n[1] Return to Main Menu\n[2] Exit"); 
                        System.out.print("Enter choice: ");int choice = rosh.nextInt();
                        switch(choice){
                            case 1: System.out.println("\nReturning to Main Menu..."); return previousBalance;
                            case 2: System.out.println("\nThank you for trusting YDB.\nProgram ending...\n"); System.exit(0); break;
                            default : System.out.println("Invalid Input. Please Try Again.");
                }
                } catch(InputMismatchException gel){
                        System.out.println("Invalid Input. Please enter a number.\n"); rosh.next();
             }  
        }   
       
    }
    public static void userDetails(){
        Details jas = new Details();
        jas.viewDetails();
    }

    public static void check(){
            System.out.println("\n****************************************");
            System.out.println("*          Do you want to exit?        *");
            System.out.println("*       --------        --------       *");
            System.out.println("*         YES              NO          *");
            System.out.println("*       --------        --------       *");
            System.out.println("****************************************\n");

            while(true){
                System.out.print("Enter choice [YES/NO]: "); String check = rosh.next().toUpperCase();
                if(check.equals("YES")){
                    System.out.println("\nThank you for trusting YDB.\nProgram ending...\n"); 
                    System.exit(0);
                } 
                else if(check.equals("NO")){
                    return;
                }
                else{
                    System.out.println("Invalid input.");
                }
        }
    }  
}




// import java.util.Scanner;
// import java.text.DecimalFormat;
// import java.util.InputMismatchException;

// public class Menus {
    
//     //static double balance = 10000;
//     static Scanner rosh = new Scanner(System.in);
//     static DecimalFormat df = new DecimalFormat("#,##0.00");
//     public void seeMenu(String name){
//         GetSet eto = new GetSet();

//         while(true){
//             System.out.println("\nWelcome " + name + "!\n");
//             System.out.println("What would you like to do?");
//             System.out.println("""
//                     [1] Deposit
//                     [2] Withdraw
//                     [3] View User Details
//                     [4] Exit
//                     """);

//                 try{
//                     System.out.print("Enter choice: "); int choice = rosh.nextInt();
//                     switch(choice){
//                         case 1 : deposit(eto.previousBalance, eto.currentBalance); break; 
//                         case 2 : withdraw(eto.previousBalance, eto.currentBalance); break;
//                         case 3 : userDetails(); break;
//                         case 4 : check(); break;
//                         default : System.out.println("Invalid Input. Try Again.");
//                     }
//                 }
//                 catch(InputMismatchException lenon){
//                     System.out.print("Invalid Input. Please enter a number.\n"); rosh.next();
//                 }
//         }  
//     }

//     public double deposit(double currentBalance, double previousBalance){
//         // Deposit angel = new Deposit(); // class
//         // angel.deposit(); // method name
//             GetSet yo = new GetSet();
//             // double currentBalance = 1000;
//             while(true) {
//                 System.out.println("Balance: Php " + df.format(yo.computeCurrentBalance()));
//                 System.out.print("Input the amount of money to deposit: Php ");
//                 //double totalDeposited = 0;
    
//                 //while(true) {
//                     yo.setDeposit(rosh.nextDouble());
//                     if (yo.deposit <= 0) {
//                         System.out.println("Invalid input. Input a positive number.");
//                         continue;
//                     } 
//                     else{ 
//                         break;
//                     }
//                     //totalDeposited += yo.getDeposit();
//                     // if (totalDeposited < 5000) {
//                     //     System.out.println("Total deposited amount is below Php 5000. Add more.");
//                     //     System.out.print("Input the amount of money to deposit: Php ");
//                    // }
//             //}
//             }
//                 //double newBalance = currentBalance + totalDeposited;
//                 System.out.println("New balance: Php " + df.format(yo.computeCurrentBalance())); 
//                 yo.previousBalance = yo.computeCurrentBalance() ;
//             while(true){
//                 System.out.println("[1] Return to Main Menu");
//                 System.out.println("[2] Exit");
//                 System.out.print("Enter your choice: ");
//                 int choice = rosh.nextInt();
//                 if(choice == 1){
//                     return previousBalance; // + previousbal
//                 }
//                 else if(choice == 2){
//                     System.out.println("Program ending...");
//                     System.exit(0);
//                 }
//                 else{
//                     System.out.println("Invalid choice.");
//                 }
//             }
//             //     switch (choice) {
//             //         // case 1: return yo.previousBalance; return yo.currentBalance; break;
//             //         // case 2: System.exit(0); break;
//             //         // default: System.out.println("Invalid choice.");
                
//             // }
//     }
//     public double withdraw(double currentBalance, double previousBalance){
//         // Withdraw yons = new Withdraw();
//         // yons.withdraw();
//         GetSet go = new GetSet();
//         while(true){
//             try{
//                 System.out.println("Balance: "+ go.computeCurrentBalance()); 
//                 System.out.print("\nEnter amount to Withdraw: "); go.setWithdraw(rosh.nextDouble()); 
//                 //double computation = balance - withdraw;
//                 // while(true){
//                     if(go.computeCurrentBalance() < 200){
//                         System.out.println("Insufficient balance, you cannot withdraw.\nPlease re-enter an amount.\n"); continue;
//                     }
//                     else{
//                     }
//                     // for (double i = go.computation(); i <= 200 ; i++) {
//                     //     System.out.println("Insufficient balance, you cannot withdraw.\nPlease re-enter an amount."); continue;
//                     //     //System.out.print("Enter amount to Withdraw: "); withdraw = scan.nextDouble(); 
//                     // }
//                 // }
//                 check();
//                 System.out.println("\nCurrent Balance: "+ df.format(go.computeCurrentBalance()));
//                 System.out.println("Congratulations you have successfully withdrawn PHP "+ df.format(go.getWithdraw()));
//                 go.previousBalance = go.currentBalance;
                    
//                         System.out.println("\n[1] Return to Main Menu\n[2] Exit"); 
//                         System.out.print("Enter choice: ");int choice = rosh.nextInt();
//                         switch(choice){
//                             case 1: System.out.println("\nReturning to Main Menu..."); return previousBalance;
//                             case 2: System.out.println("\nThank you for trusting YDB.\nProgram ending...\n"); System.exit(0); break;
//                             default : System.out.println("Invalid Input. Please Try Again.");
//                 }
//                 } catch(InputMismatchException gel){
//                         System.out.println("Invalid Input. Please enter a number.\n"); rosh.next();
//              }  
//         }   
       
//     }
//     public static void userDetails(){
//         Details jas = new Details();
//         jas.viewDetails();
//     }

//     public static void check(){
//             System.out.println("\n****************************************");
//             System.out.println("*          Do you want to exit?        *");
//             System.out.println("*       --------        --------       *");
//             System.out.println("*         YES              NO          *");
//             System.out.println("*       --------        --------       *");
//             System.out.println("****************************************\n");

//             while(true){
//                 System.out.print("Enter choice [YES/NO]: "); String check = rosh.next().toUpperCase();
//                 if(check.equals("YES")){
//                     System.out.println("\nThank you for trusting YDB.\nProgram ending...\n"); 
//                     System.exit(0);
//                 } 
//                 else if(check.equals("NO")){
//                     return;
//                 }
//                 else{
//                     System.out.println("Invalid input.");
//                 }
//         }
//     }  
// }
