import java.util.Scanner;
// import java.io.FileWriter;
// import java.io.IOException;
// import java.io.File;
import java.util.InputMismatchException; 

public class Main_Program {
    static Scanner rosh = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("||========================================||");
        System.out.println("||:......................................:||");
        System.out.println("||:......................................:||");
        System.out.println("||:                                      :||");
        System.out.println("||:         Hello Dear Customer,         :||");
        System.out.println("||:           WELCOME TO YDB!            :||");
        System.out.println("||:            [add slogan]              :||");
        System.out.println("||:                                      :||");
        System.out.println("||:......................................:||");
        System.out.println("||:......................................:||");
        System.out.println("||========================================||");

        while(true){
            displayMenu();
            try{
                int choice = getChoice();
                switch(choice){
                    case 1 : createAccount(); break;
                    case 2 : login(); break;
                    case 3 : confirmation(); break;
                    default : System.out.println("Invalid Input. Try Again.");
                } 
            }
            catch(InputMismatchException lenon){
                System.out.print("Invalid Input. Please enter a number.\n");
                rosh.next(); 
            }
         }
    }
    public static void confirmation(){
            System.out.println("\n****************************************");
            System.out.println("*          Do you want to exit?        *");
            System.out.println("*       --------        --------       *");
            System.out.println("*         YES              NO          *");
            System.out.println("*       --------        --------       *");
            System.out.println("****************************************\n");

            while(true){
                System.out.print("Enter choice [YES/NO]: "); String ans = rosh.next().toUpperCase();
                if(ans.equals("YES")){
                    System.out.println("\nThank you for trusting YDB.\nProgram ending...\n"); 
                    System.exit(0);
                } 
                else if(ans.equals("NO")){
                    return;
                }
                else{
                    System.out.println("Invalid input.");
                }
        }
    }
    public static void displayMenu() {
        System.out.println("\n============================================");
        System.out.println("    PLEASE LOG IN OR SIGN UP TO CONTINUE    ");
        System.out.println("============================================\n");
        System.out.println("[1] Create an Account");
        System.out.println("[2] Login");
        System.out.println("[3] Exit");
    }

    public static int getChoice() {
        System.out.print("Enter choice [1-3]: ");
        return rosh.nextInt();
    }

    public static void createAccount() {
        Create yons = new Create();
        yons.createAccount();
        // try (FileWriter writer = new FileWriter("accounts.txt", true)) {
        //     System.out.println("Creating a new account...");
        //     System.out.print("Enter Name: ");
        //     String name = rosh.next();
        //     System.out.print("Enter Account Number: ");
        //     String accNumber = rosh.next();
        //     System.out.print("Enter Pin: ");
        //     String pin = rosh.next();
        //     writer.write("Name: " + name + ", Account Number: " + accNumber + ", Pin: " + pin + "\n");
        //     System.out.println("Account created successfully!");
        // } catch (IOException e) {
        //     System.out.println("An error occurred while writing to file.");
        //     e.printStackTrace();
        // }
    }

    public static void login() {
        Login gel = new Login();
        gel.LoginAcc();

    //     System.out.println("Logging in...");
    //     System.out.print("Enter Name: ");
    //     String name = rosh.next();
    //     System.out.print("Enter Account Number: ");
    //     String accNumber = rosh.next();
    //     System.out.print("Enter Pin: ");
    //     String pin = rosh.next();
    //     if (authenticateUser(name, accNumber, pin)) {
    //         System.out.println("You have been logged in successfully!");
    //     } else {
    //         System.out.println("Login failed.\nPlease check your credentials or Sign up to create an Account.");
    //     }
    }

    // public static boolean authenticateUser(String name, String accNumber, String pin) {
    //     try (Scanner fileScanner = new Scanner(new File("accounts.txt"))) {
    //         while (fileScanner.hasNextLine()) {
    //             String line = fileScanner.nextLine();
    //             if (line.contains("Name: " + name) && line.contains("Account Number: " + accNumber) && line.contains("Pin: " + pin)) {
    //                 return true;
    //             }
    //         }
    //     } catch (IOException e) {
    //         System.out.println("An error occurred while reading the accounts file.");
    //         e.printStackTrace();
    //     }
    //     return false;
    // }

}
