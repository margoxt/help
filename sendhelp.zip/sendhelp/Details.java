import java.text.DecimalFormat;

public class Details {
    static DecimalFormat df = new DecimalFormat("##.00");

    public void viewDetails(){
        GetSet yons = new GetSet(); 
        
        System.out.println("\n============================================");
        System.out.println("             ACCOUNT DETAILS                  ");
        System.out.println("============================================\n");

        System.out.println("Name: "+ yons.getName());
        System.out.println("Account Number: "+ yons.getNum());
        System.out.println("Balance: "+ df.format(yons.getCurrentBalance()));
    }  
}
