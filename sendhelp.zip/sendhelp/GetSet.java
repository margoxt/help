
public class GetSet {

    // fields
    String name, pin, accNum;
    // double balance, deposit, withdraw, remaining_balance, computed_balance, comBalance, initialDeposit;
    double previousBalance=0, currentBalance=0, deduction=0, deposit=0, withdraw=0;

    // setter
    public double setBalance(double bal){ // prev val ka-sign up ni user
        previousBalance = bal;
        return previousBalance;
    }
    public double setWithdraw(double withd){ // money na winithdraw
        withdraw = withd;
        return withdraw;
    }
    public double setDeposit(double dep){ // money na dineposit
        deposit = dep; 
        return deposit;
    }
    // public void setInitialDeposit(double inDep){
    //     initialDeposit = inDep; 
    // }


    // computation
    public double computeDeduction(){
        deduction= withdraw * 0.02;
        return deduction;
    }
    public double computeCurrentBalance(){
        currentBalance = previousBalance + deposit - withdraw - deduction;
        return currentBalance;
    }

    // public double computation(){ // after withdrawal
    //     balance -= withdraw;
    //     computed_balance = balance - (balance * 0.02);
    //     return computed_balance; // should not be less than PHP 200
    // }

    // public double remain(){ // for display sa user deets
    //     remaining_balance = deposit + computed_balance; // add ung money na dineposit doon sa computed
    //     return remaining_balance;  
    // }

    // public double compBalance(){ // before withdraw
    //     comBalance = deposit + balance; // d ko alam pero uhh
    //     return comBalance; 
    // } 


    // getters 
    public String getName(){
        return name;
    }
    public String getNum(){
        return accNum;
    }
    public double getBalance(){
        return previousBalance; // changing value
    }
    public double getCurrentBalance(){
        return currentBalance;
    }
    public double getDeposit(){
        return deposit;
    }
    public double getWithdraw(){
        return withdraw;
    }   
    // public double getPreviousBalance(){
    //     return previousBalance;
    // }
    // public double getInitialDeposit(){
    //     return initialDeposit;
    // }  
}
