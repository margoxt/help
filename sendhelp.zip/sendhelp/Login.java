// import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
// import java.util.InputMismatchException;
import java.util.Scanner;

public class Login {
    static Scanner rosh = new Scanner (System.in);
    public void LoginAcc(){
        System.out.println("\nPlease wait for a few moments...");
        System.out.println("Logging in...\n");
        System.out.println("============================================");
        System.out.println("                 LOG IN                     ");
        System.out.println("============================================\n");
    
        // try{
        System.out.print("Enter Name: "); String name = rosh.next();
        System.out.print("Enter Account Number: "); String accNum = rosh.next();
        System.out.print("Enter Pin: "); String pin = rosh.next();
        if (authenticateUser(name, accNum, pin)) {
            System.out.println("\n=========================================");
            System.out.println("  You have been logged in successfully!  ");
            System.out.println("=========================================");
            showMenu(name);
        } else {
            System.out.println("\nLogin failed.\nPlease check your credentials or Sign up to create an Account."); 
        } 
    // }   catch(InputMismatchException e){
    //         System.out.print("Invalid Input.\n");
    //         System.out.println(e);; 
    // }
} 
    public static boolean authenticateUser(String name, String accNum, String pin) {
        try (Scanner fileScanner = new Scanner(new File("accounts.txt"))) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                if (line.contains("Name: " + name) && line.contains("Account Number: " + accNum) && line.contains("Pin: " + pin)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the accounts file.");
            e.printStackTrace();
        }
        return false;
    }

    public void showMenu(String name){
        Menus jasmine = new Menus();
        jasmine.seeMenu(name);
    }    
}
