import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Create {
    static GetSet kuha = new GetSet();
    static Scanner rosh = new Scanner(System.in);

    public void createAccount() {
        System.out.println("\nPlease wait for a few moments...");
        System.out.println("Creating a new account...\n");
        System.out.println("============================================");
        System.out.println("             CREATE AN ACCOUNT              ");
        System.out.println("============================================\n");
    
        while (true) {
            //double initialDeposit; // Declare initialDeposit here once
    
            try (FileWriter writer = new FileWriter("accounts.txt", true)) {
                System.out.print("Enter First Name: ");
                String name = rosh.next();
                System.out.print("Enter Account Number [8 digits]: ");
                String accNum = rosh.next();
                if (accNum.length() != 8) {
                    System.out.println("\nYour Account Number should be 8 digits.\nPlease Re-enter your credentials.\n");
                    continue;
                }
                String pin = confirmPin();
                System.out.print("Enter Initial Deposit Amount: PHP "); kuha.setBalance(rosh.nextDouble());
                // initialDeposit = rosh.nextDouble();
                // kuha.setInitialDeposit(initialDeposit); // Set initial deposit in GetSet object
                writer.write("Name: " + name + ", Account Number: " + accNum + ", Pin: " + pin + ", Initial Deposit: PHP " + kuha.getBalance() + ", Current Balance: PHP "+ kuha.computeCurrentBalance() + "Deposit: " + kuha.getDeposit()+ "\n");
                System.out.println("\nAccount created successfully!\nLogin to your new account to continue."); 
                break; // Exit loop after successful account creation
            } catch (IOException e) {
                System.out.println("An error occurred while writing to file.");
                e.printStackTrace();
            }
        }
    }

    public static String confirmPin() {
        while (true) {
            System.out.print("Enter PIN [4 digits]: ");
            String pin = rosh.next();

            if (pin.length() != 4) {
                System.out.println("\nYour PIN should be 4 digits.\nPlease Re-enter your credentials.\n");
                continue;
            } else {
                System.out.print("Confirm PIN: ");
                String cPin = rosh.next();
                if (cPin.equals(pin)) {
                    return pin;
                } else {
                    System.out.println("\nYour PIN doesn't match. Try Again.\n");
                    continue;
                }
            }
        }
    }
}




// import java.util.Scanner;
// import java.io.FileWriter;
// import java.io.IOException;
// // import java.io.File;

// public class Create {


    // static GetSet kuha = new GetSet();
    // static Scanner rosh = new Scanner (System.in);
    
    // public void createAccount(){ 
    //     // GetSet progsdats = new GetSet();
    //     System.out.println("\nPlease wait for a few moments...");
    //     System.out.println("Creating a new account...\n");
    //     System.out.println("============================================");
    //     System.out.println("             CREATE AN ACCOUNT              ");
    //     System.out.println("============================================\n");

    //     while (true) {
    //         double initialDeposit; 

    //         try (FileWriter writer = new FileWriter("accounts.txt", true)) {
    //             System.out.print("Enter First Name: ");
    //             String name = rosh.next();
    //             System.out.print("Enter Account Number [8 digits]: ");
    //             String accNum = rosh.next();
    //             if (accNum.length() != 8) {
    //                 System.out.println("\nYour Account Number should be 8 digits.\nPlease Re-enter your credentials.\n");
    //                 continue;
    //             }
    //             String pin = confirmPin();
    //             // System.out.print("Enter Initial Deposit Amount: PHP ");
    //             initialDeposit = rosh.nextDouble();
    //             kuha.setInitialDeposit(initialDeposit); 
    //             writer.write("Name: " + name + ", Account Number: " + accNum + ", Pin: " + pin + ", Initial Deposit: PHP " + initialDeposit + "\n");
    //             System.out.println("\nAccount created successfully!\nLogin to your new account to continue.");
    //             break; 
    //         } catch (IOException e) {
    //             System.out.println("An error occurred while writing to file.");
    //             e.printStackTrace();
    //         }
    //     }
    // }
    //     // while(true){
    //     //     try (FileWriter writer = new FileWriter("accounts.txt", true)) {
    //     //         double initialDeposit;
    
    //     //         System.out.print("Enter First Name: "); String name = rosh.next(); 
    //     //         System.out.print("Enter Account Number [8 digits]: "); String accNum = rosh.next();
    //     //         if(accNum.length() > 8 || accNum.length() < 8){
    //     //             System.out.println("\nYour Account Number should be 8 digits.\nPlease Re-enter you credentials.\n");
    //     //             continue;
    //     //         }
    //     //         String pin= confirmPin();
    //     //         initialDeposit = rosh.nextDouble();
    //     //         kuha.setInitialDeposit(initialDeposit);
    //     //         writer.write("Name: " + name + "Account Number: " + accNum + "Pin: " + pin + "Deposit: "+ initialDeposit+"\n");
    //     //         System.out.println("\nAccount created successfully!\nLogin to your new account to continue."); break; //
    //     //     } catch (IOException e) {
    //     //         System.out.println("An error occurred while writing to file.");
    //     //         e.printStackTrace(); 
    //     //     }
    //     // }
    

    // public static String confirmPin(){
    //     while(true){
    //         System.out.print("Enter PIN [4 digits]: "); String pin = rosh.next(); 

    //         if(pin.length() > 4 || pin.length() < 4 ){
    //             System.out.println("\nYour PIN should be 4 digits.\nPlease Re-enter you credentials.\n");
    //             continue;
    //         }
    //         else{ 
    //             System.out.print("Confirm PIN: "); String cPin = rosh.next();
    //             if(cPin.equals(pin)){
    //                 while(true){
    //                     System.out.print("Please deposit a minimum of PHP 5,000.00 to continue: PHP "); kuha.setBalance(rosh.nextDouble()); //balance+=balance;
    //                     if(kuha.getBalance() < 5000){
    //                         System.out.println("\nYou need to atleast deposit a minimum of PHP 5,000.00.\n");
    //                         // System.out.print("Deposit an amount: PHP "); balance= rosh.nextDouble(); balance += balance;
    //                         // continue;
    //                     }
    //                     else{
    //                         return pin;
    //                     }
    //                 }  
    //             } 
    //             else{
    //                 System.out.println("\nYour PIN doesn't match. Try Again.\n"); continue;
    //             }
    //         } 
    //     }
    // }
    //     double balance=0;
    //     GetSet jasmine = new GetSet();
    //     boolean y = false;
    //     while(y == false){
    //     System.out.print("Create your account "); 
    //     rosh.nextLine();
    //     System.out.print("Enter Name: "); String name = rosh.nextLine();
    //     System.out.print("Enter Account Number [8 Digits]: "); String accNum= rosh.nextLine();
    //     if(accNum.length() > 8 || accNum.length() < 8){
    //         System.out.println("Your Account Number should be 8 digits.\n");
    //         continue;
    //     }
    //     System.out.print("Enter PIN [4 Digits]: "); String pin = rosh.nextLine();
    //     if(pin.length() > 4 || pin.length() < 4 ){
    //         System.out.println("Your PIN should be 4 digits.\n");
    //         continue;
    //     }
        // else{ 
        //     System.out.print("Confirm PIN: "); String cPin = rosh.nextLine();
        //     if(cPin.equals(pin)){
        //         System.out.print("Please deposit a minimum of PHP 5,000.00 to continue: PHP "); balance= rosh.nextDouble(); balance+=balance;
        //         if(balance < 5000){
        //             System.out.println("You need to atleast deposit a minimum of PHP 5,000.00.");
        //             System.out.print("Deposit an amount: PHP "); balance= rosh.nextDouble(); balance += balance;
        //             continue;
        //         }
        //         else{
        //             System.out.print("You have successfully created your account!");
        //             showMenu(name);
        //         }
        //     } else{
        //         System.out.println("Your PIN doesn't match. Try Again.\n"); 
        //     }
        // } 
    //}
    // }
    // public void showMenu(String name){
    //     Menus jasmine = new Menus(name);
    //     jasmine.seeMenu(name);
     
//}


